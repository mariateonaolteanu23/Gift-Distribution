package observers;

public interface Observer {
    /**
     * Updates user of a change in DeliveryAction class
     */
    void update();
}
